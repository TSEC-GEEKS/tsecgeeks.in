#include<stdio.h>

void main()
{
    int sum = 0, n;
    int a = 0;
    int b = 1;
    printf("Enter the nth value: ");
    scanf("%d", & n);
    printf("Fibonacci series: ");
    while (sum <= n)
    {
        printf("%d ", sum);
        a = b; // swap elements
        b = sum;
        sum = a + b; // next term is the sum of the last two terms
    }
}
