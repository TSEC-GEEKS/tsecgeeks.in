#include<stdio.h>
void main()
{
    int i, j, k, n, a = 0;
    printf("Enter the number of rows: ");
    scanf("%d", &n);
    while(a <= 10)
    {
        printf("\n");
        a++;
    }
    for(i=1; i<=n; i++) // for rows
    {
        for(j=1; j<=n-i; j++)
        {
            printf(" ");
        }
        for(j=1; j<=i; j++) //for columns
        {
            printf("*"); // a = 65 b = 66
        }
        for(k=1; k<i; k++)
        {
            printf("%c", k+64); // A = 65, a = 97
        }
        printf("\n");
    }
}